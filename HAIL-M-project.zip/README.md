# HAIL-M Project

This project integrates with HubSpot using the HubSpot CLI.
