// Add client-side JS here
console.log('Client JS loaded');
